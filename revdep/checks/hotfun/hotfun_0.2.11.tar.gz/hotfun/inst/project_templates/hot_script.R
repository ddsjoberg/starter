# if repo is hosted at https://github.mskcc.org/Analytic-Projects do the following:
# 1. Set repo to private
# 2. Add phi topic hashtag

# get url of origin
remote_origin_url <-
  gert::git_remote_list(repo = path) %>%
  dplyr::filter(.data$name %in% "origin") %>%
  dplyr::pull(.data$url)


# if repo is in Analytic-Projects org, then make repo private and add PHI tag
if (isTRUE(
  stringr::str_detect(stringr::fixed(remote_origin_url),
                      pattern = stringr::fixed("github.mskcc.org/Analytic-Projects")))) {
    # save repo name
    repo_name <-
      remote_origin_url %>%
      fs::path_file() %>%
      fs::path_ext_remove()

    if (!requireNamespace("hotverse")) {
      paste("The 'hotverse' package is not installed and the repository",
            "cannot be set to 'private' and the '#phi' tag could not be",
            "added. Visit https://github.mskcc.org/pages/hot/hotverse/", "
            for installation instructions.") %>%
        stringr::str_wrap() %>%
        message()
    }
    else {
      hotverse::use_github_msk_private_repo(repo = repo_name, org = "Analytic-Projects")
      hotverse::use_github_msk_phi_repo(repo = repo_name, org = "Analytic-Projects")
    }
  }
