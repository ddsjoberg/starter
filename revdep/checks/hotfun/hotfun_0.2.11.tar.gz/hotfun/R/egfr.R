#' Calculate eGFR
#'
#' @param creatinine serum creatinine level in mg/dL
#' @param age patient age
#' @param female logical indicating whether patient is female
#' @param aa logical indicating whether patient is African-American
#' @param label label that will be applied to result,
#' e.g. `attr("label", 'eGFR, mL/min/1.73m\U00B2')`
#'
#' @rdname egfr
#' @return numeric vector
#' @export
#'
#' @examples
#' egfr_mdrd(creatinine = 1.2, age = 60, female = TRUE, aa = TRUE)
egfr_mdrd <- function(creatinine, age, female, aa,
                      label = "eGFR, mL/min/1.73m\U00B2") {
  if (!is.numeric(creatinine) || !is.numeric(age) ||
      !is.logical(female) || !is.logical(aa)) {
    stop("Arguments `creatinine` and `age` must be numeric, and `female` and `aa` logical.")
  }

  egfr <-
    175 * creatinine^-1.154 * age^-0.203 * ifelse(female, 0.742, 1) * ifelse(aa, 1.212, 1)
  attr(egfr, "label") <- label
  egfr
}
