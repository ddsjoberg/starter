library(testthat)
library(hotfun)

test_check("hotfun")
