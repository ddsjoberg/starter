
<!-- README.md is generated from README.Rmd. Please edit that file -->

# mskRutils

<!-- badges: start -->

[![Lifecycle:
maturing](https://img.shields.io/badge/lifecycle-maturing-blue.svg)](https://www.tidyverse.org/lifecycle/#maturing)
![Coverage](https://img.shields.io/badge/Code%20Coverage-21%25-red)
<!-- badges: end -->

The {mskRutils} is a collection of utility functions useful when
programming at MSKCC. Some functions aid in interfacing the MSK instance
of GitHub Enterprise, and others aid in setting up project folders.

## Installation

1.  **One-time** configuration of the [MSK RStudio Package
    Manager](https://github.mskcc.org/pages/datadojo/mskR/articles/rspm.html)

    ``` r
    install.packages("rstudio.prefs")
    rstudio.prefs::use_rstudio_secondary_repo(
      MSK_RSPM = "http://rspm.mskcc.org/MSKREPO/latest"
    )
    ```

2.  Install {mskRutils} from the MSK RStudio Package Manager

    ``` r
    install.packages("mskRutils")
    ```

## mskR Universe

The {mskRutils} package is one of a few packages part of the {mskR}
universe. Visit
[mskr.mskcc.org](https://github.mskcc.org/pages/datadojo/mskR/index.html)
to learn more.

## Other Utility Packages

There are many other packages that contain great utility functionality.
Check out the packages below.

-   [usethis](https://usethis.r-lib.org/): Automates repetitive tasks
    that arise during project setup and development, both for R packages
    and non-package projects.

-   [datapasta](https://github.com/milesmcbain/datapasta): Reduces
    resistance associated with copying and pasting data to and from R.

-   [clipr](https://github.com/mdlincoln/clipr): R functions for reading
    and writing from the system clipboard.
