# {{folder_name}}

# Symbolic Link to Secure Data
{{symbolic_link}}
