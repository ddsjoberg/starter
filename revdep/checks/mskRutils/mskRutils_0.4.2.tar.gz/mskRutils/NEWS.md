# mskRutils 0.4.2

- Improved error messaging in `github_msk_token()`.

# mskRutils 0.4.1

- Updated functions `create_msk_project()`, `use_msk_file()`, `create_symlink()` to depend on the {starter} package.

- Deleted deprecated function `copy_to_clipboard()`.

- Updated functions `use_msk_rspm()`, `use_rstudio_preferences()`, `use_rstudio_keyboard_shortcut()` to utilize the {rstudio.prefs} package.

- Adding `use_github_msk()` function to connect a local git repo to MSK GitHub (#30)

- Added a vignette detailing how to setup the MSK GitHub Personal Access Token (PAT).

- Misc. updates to the documentation.

- Removed unneeded packages from DESCRIPTION file.

# mskRutils 0.4.0

- Updated function `github_msk_token()` to wrap `gh::gh_token()` to search for the MSK GitHub PAT. PATs stored as environmental variables are now deprecated, but the function will still return a PAT found there if `gh::gh_token()` fails.

- Deprecated function `browse_github_msk_token()` as this method of GitHub PAT is now deprecated in the usethis package. Added new function `create_github_msk_token()` to wrap the updated `usethis::usethis::create_github_token()` to create the PAT. (#130)

- Added function `has_msk_network_access()` that assesses whether or not the MSK network is available.

- Updated `use_msk_rspm()` and `check_rspm_setup()` to use the full address of RSPM (`http://rspm.mskcc.org/MSKREPO/latest`) instead of the shortcut location.

# mskRutils 0.3.0

- Added `renv` argument to `create_msk_project()` (#124)

- Fix to default .gitignore for temporary Windows files.

- Updated `use_msk_file()` to prompt users for a new file name when file already exists. (#123)

- Added `check_rspm_setup()` function that checks whether the MSK RSPM is properly set up.

- Updated `create_msk_project` to use "file" option rather than deprecated "path" option in `readr::write_file`

# mskRutils 0.2.5

- Added three functions to set the MSK RSPM (`set_msk_rspm()`), RStudio preferences (`set_rstudio_preferences()`), and mskRutils addins (`set_rstudio_addins()`) (#63)

- `use_github_msk_release()` now adds the release date to the tag header (#117)

# mskRutils 0.2.4

- Added `%not_in%` function (#103)

- `github_msk_token()` now returns the actual token, if available (#109)    

- Added a MSK GitHub release function, `use_github_msk_release()` (#85)   

- `create_msk_project()` now provides Applied Data Science team's project template (#12)  

# mskRutils 0.2.3

- Created function for code coverage badge, and added badge to README (#79)

- Added renv and .swp files to gitignore in default template (#69)

- Added `make_path_norm()` add-in to apply `fs::path_norm()` to normalize paths on selected text (#83)

- Updated name of the default template object name (#93)


# mskRutils 0.2.2

- GUI for `create_msk_project()` works with all templates

# mskRutils 0.2.1

- Migrated `hot` and `biostat` templates to their respective packages

- Fixed file naming bug in `use_msk_file()` (#58)

- Added GitHub Issue Template

- Added vignette for adding a local Git Repo to MSK GitHub (#28)

- Added additional input checks in `create_symlink()` (#39)

- Updated the default gitignore files to include missing items from https://github.mskcc.org/datadojo/git_resources/blob/master/gitignore_template.txt

- Added unit tests (#19)

- Added quiet argument to `create_msk_project()` and `use_msk_file()` (#36)

- Improved documentation for `install_github_msk()`, `browse_github_msk_token()`, and `github_msk_token()` (#21)

- The `use_github_msk()` has been removed (#30)

# mskRutils 0.2.0

- Updated name of `start_project()` function to `create_msk_project()` (#20)

- Added function to create any file from a project template `use_msk_file()`. Also added two shortcuts for this function: `use_msk_gitignore()` and `use_msk_readme()` (#17)

- Added `biostat` template to `create_msk_project()` (#10)

- Updated default *.Rproj file to not restore workspace on startup and not to save workspace when closed.

- Updated `hot` template in  `create_msk_project()`

- Deprecated clipboard function, and updated README to include references to other great utility packages.

- Updates to `create_symlink()` to take two arguments. 1. Path to linked folder, 2. The name of the folder (default is 'secure_data').  Function now infers the location of the project and placed the symbolic link folder there. 

# mskRutils 0.1.0

* First release of package after conscious uncoupling of the {mskR} package
