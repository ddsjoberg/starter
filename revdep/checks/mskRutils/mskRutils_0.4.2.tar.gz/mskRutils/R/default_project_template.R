#' Default project template
#'
#' The `default_project_template` object defines the contents of the default project
#' template used in `create_msk_project()` and `use_msk_file()`.
#'
#' @format A quoted list defining the default project template. Each item of
#' the list identifies one script or document that appears in the project template.
#' @examples
#' create_msk_project(
#'   path = file.path(tempdir(), "Sjoberg New Project"),
#'   template = mskRutils::default_project_template
#' )
#' @seealso [create_msk_project()]
#' @seealso [use_msk_file()]
#' @seealso [Vignette for create_msk_project()](https://github.mskcc.org/pages/datadojo/mskRutils/articles/create_msk_project.html)
"default_project_template"
