#' Deprecated functions
#'
#' Some functions have been deprecated and are no longer being actively
#' supported.
#'
#' @name deprecated
#' @keywords internal
NULL

#' @rdname deprecated
#' @export
start_project <- function(...) {
  lifecycle::deprecate_stop(
    "0.2.0",
    "mskRutils::start_project()"
  )
}

#' @rdname deprecated
#' @export
browse_github_msk_token <- function() {
  paste("You must setup your MSK GitHub credentials using the {ui_field('gitcreds')} package.",
        "Visit the {ui_field('Happy Git and GitHub for the useR')} website",
        "for step-by-step instructions. Replace the {ui_value('url')} argument",
        "with {ui_value('url = \"https://github.mskcc.org\"')}") %>%
    usethis::ui_todo()
  usethis::ui_code_block("https://happygitwithr.com/credential-caching.html")

  lifecycle::deprecate_stop("0.3.1", "mskRutils::browse_github_msk_token()")
}
