#' Check the MSK RSPM is setup properly
#'
#' @param quiet Suppress function messaging
#' @export
#' @seealso [RSPM Vignette](https://github.mskcc.org/pages/datadojo/mskR/articles/rspm.html)

check_rspm_setup <- function(quiet = FALSE) {
  # if quiet, then just skip the entire function!
  if (quiet == TRUE) return(invisible(NULL))

  # get list of current repos
  repos <- getOption("repos")

  rspm_locations <-
    c("http://rspm/MSKREPO/latest",
      "http://rspm.mskcc.org/MSKREPO/latest")

  # checking if MSK_RSPM is setup
  if (!any(rspm_locations %in% repos)) {
    ui_info("The MSK RStudio Package Manager is not setup on this machine.")
    ui_todo("Set it up with {ui_code('mskRutils::use_msk_rspm()')}")
    ui_todo("More details at")
    ui_code_block("https://github.mskcc.org/pages/datadojo/mskR/articles/rspm.html")
  }

  # checking the MSK_RSPM is called MSK_RSPM
  if (any(rspm_locations %in% repos) && !"MSK_RSPM" %in% names(repos)) {
    wrong_name <- names(repos[repos %in% rspm_locations])
    paste0("The MSK RStudio Package Manager is setup on this machine. ",
           "But the current name, ", shQuote(wrong_name), ", ",
           "does not follow the MSK naming convention.") %>%
      stringr::str_wrap() %>%
      ui_info()
    ui_todo("Update the name to \"MSK_RSPM\" by calling {ui_code('mskRutils::use_msk_rspm()')}")
    ui_todo("More details at")
    ui_code_block("https://github.mskcc.org/pages/datadojo/mskR/articles/rspm.html")
  }
  return(invisible(NULL))
}
