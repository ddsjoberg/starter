#' @title Set Rstudio preferences
#'
#' @description
#' \lifecycle{experimental}
#' Use these function to setup the MSK RStudio Package Manager, and
#' to set RStudio preferences chosen as best practice.
#'
#' @param path_prefs Optional path to custom preferences to update.
#'
#' @details
#' - [use_msk_rspm()] Set the MSK RSPM is a secondary repository
#' - [use_rstudio_preferences()] Set default preferences for RStudio
#' - [use_rstudio_keyboard_shortcut()] Set mskRutils addin shortcuts
#'     - `rstudio.prefs::make_path_norm()` shortcut Ctrl+Shift+/
#'
#' @rdname use_rstudio
#' @export
#' @examples
#'
#' # # Set MSK RStudio Package Manager repository
#' # use_msk_rspm()
#'
#' # # Set RStudio defaults for best practices
#' # use_rstudio_preferences()
#'
#' # # Set mskRutils keyboard shortcuts
#' # use_rstudio_keyboard_shortcut()
use_msk_rspm <- function() {
  rstudio.prefs::check_min_rstudio_version("1.3")
  lst_new_repos <- list(MSK_RSPM = "http://rspm.mskcc.org/MSKREPO/latest")

  # replacing shortcut RSPM location, if needed --------------------------------
  lst_existing_repos <-
    jsonlite::fromJSON(rstudio.prefs::rstudio_config_path("rstudio-prefs.json")) %>%
    purrr::pluck("cran_mirror", "secondary") %>%
    rstudio.prefs::repo_string_as_named_list()
  old_rspm_loc_lgl <-
    purrr::map_lgl(lst_existing_repos, ~identical(.x, "http://rspm/MSKREPO/latest"))
  if (any(old_rspm_loc_lgl)) {
    lst_new_repos <-
      lst_existing_repos[old_rspm_loc_lgl] %>%
      purrr::map(~NULL) %>%
      purrr::list_modify(!!!lst_new_repos)
  }

  # adding MSK_RSPM repo -------------------------------------------------------
  rstudio.prefs::use_rstudio_secondary_repo(!!!lst_new_repos)
}

#' @rdname use_rstudio
#' @export
use_rstudio_preferences <- function(path_prefs = NULL) {
  # setting default location for RStudio preferences to be set -----------------
  prefs_list <-
    path_prefs %||%
    system.file("rstudio_prefs/rstudio-prefs.json", package = "mskRutils") %>%
    jsonlite::fromJSON()

  # applying preferences -------------------------------------------------------
  rstudio.prefs::use_rstudio_prefs(!!!prefs_list)
}

#' @rdname use_rstudio
#' @export
use_rstudio_keyboard_shortcut <- function(path_prefs = NULL) {
  # setting default location for RStudio preferences to be set -----------------
  prefs_list <-
    path_prefs %||%
    system.file("rstudio_prefs/addins.json", package = "mskRutils") %>%
    jsonlite::fromJSON() %>%
    invert_list_names_and_values()

  # adding shortcuts -----------------------------------------------------------
  rstudio.prefs::use_rstudio_keyboard_shortcut(!!!prefs_list)
}

invert_list_names_and_values <- function(x) {
  if (rlang::is_empty(x)) {
    return(x)
  }
  names(x) %>%
    as.list() %>%
    stats::setNames(unlist(x))
}
