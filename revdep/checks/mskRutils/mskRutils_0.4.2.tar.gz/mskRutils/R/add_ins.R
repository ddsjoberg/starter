#' Normalize Path
#'
#' \lifecycle{deprecated}
#' Use `rstudio.prefs::make_path_norm()` instead.
#' @export
make_path_norm <- rstudio.prefs::make_path_norm
