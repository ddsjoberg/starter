#' Inverted version of `%in%`
#'
#' Equivalent to `!(x %in% y)`
#'
#' @inheritParams base::match
#' @return logical vector
#' @export
#'
#' @examples
#' 1 %not_in% 1:10  #returns FALSE
#' "b" %not_in% 1:10  #returns TRUE
`%not_in%` <- function(x, table) {
  !(match(x, table, nomatch = 0) > 0)
}
