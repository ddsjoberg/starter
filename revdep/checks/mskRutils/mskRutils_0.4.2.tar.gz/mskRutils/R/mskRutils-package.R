#' @import dplyr
#' @import purrr
#' @import usethis
#' @importFrom tidyr nest unnest spread gather complete
#' @importFrom tibble tibble as_tibble
#' @importFrom rlang .data %||% set_names sym expr enexpr quo enquo
#'   parse_expr cnd caller_env ns_env is_true is_string peek_option
#' @importFrom usethis ui_done ui_field ui_value ui_yeah ui_code
#' @importFrom stringr str_detect fixed
#' @keywords internal
"_PACKAGE"

# allowing for the use of the dot when piping
utils::globalVariables(".")

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @importFrom lifecycle deprecate_soft
## usethis namespace: end
NULL
