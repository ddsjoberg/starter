#' Draft a GitHub release for a MSK package
#'
#' Wrapper around `usethis::use_github_release()` for packages hosted on MSK's GitHub enterprise server.
#'
#' @return URL to the GitHub draft release.
#'
#' @details
#' Call this function after updating the package version in the `DESCRIPTION` file
#' and adding appropriate release notes in the `NEWS.md` file.
#'
#' @export
#'
#' @examples
#' \donttest{
#' \dontrun{
#' use_github_msk_release()
#' }
#' }
use_github_msk_release <- function() {

  auth_token <- github_msk_token()

  description_path <- file.path(proj_get(), "DESCRIPTION")
  if (!file.exists(description_path)) {
    ui_stop("{ui_path('DESCRIPTION')} not found")
  }

  description_file <- readLines(description_path, encoding = "UTF-8")
  package_name <- gsub("Package: ", "",
                       description_file[grep("Package: ", description_file)])
  package_version <- gsub("Version: ", "",
                          description_file[grep("Version: ", description_file)])

  news_path <- file.path(proj_get(), "NEWS.md")
  if (!file.exists(news_path)) {
    ui_stop("{ui_path('NEWS.md')} not found")
  }
  news <- readLines(news_path, encoding = "UTF-8")
  headings <- grep("^#\\s+", news)

  if (length(headings) == 0) {
    ui_stop("No top-level headings found in {ui_value('NEWS.md')}")
  } else if (length(headings) == 1) {
    latest_news <- news[(headings[1] + 1):(length(news))]
  } else {
    latest_news <- news[(headings[1] + 1):(headings[2] - 1)]
  }

  release_tag <- trimws(gsub("^#\\s+", "", news[headings[1]]))
  release_heading <- paste0(release_tag, " (", Sys.Date(), ")")

  release_news <- paste0(latest_news, "\n", collapse = "")

  owner_package <- gsub("https://github.mskcc.org/", "", git_remotes()$origin)
  owner <- gsub(paste0("/", package_name), "", owner_package)
  owner <- gsub("\\.git$", "", owner)

  release <- gh::gh("POST /repos/:owner/:repo/releases", owner = owner,
                    repo = package_name, tag_name = paste0("v", package_version),
                    target_commitish = "master", name = release_heading,
                    body = release_news, draft = TRUE,
                    .api_url = "https://github.mskcc.org/api/v3",
                    .token = auth_token)

  # open website or print we address
  url <- paste(release$html_url, sep = "/")
  if (interactive()) {
    ui_done("Opening URL {ui_value(url)}")
    utils::browseURL(url)
  }
  else {
    ui_todo("Open URL {ui_value(url)}")
  }
  invisible(url)
}
