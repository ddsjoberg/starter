#' Code Coverage Badge
#'
#' Creates a URL for code coverage that can be added to the README.Rmd file of a package on GitHub.
#' @return Returns the URL for the code coverage badge
#' @examples
#' \dontrun{
#' # Add the following line to the README.Rmd file of a package on GitHub
#' ![Coverage](`r mskRutils::use_covr_badge()`)
#' }

#' @export

use_covr_badge <- function() {
  # if called interactively, telling user to paste badge code to README
  if (interactive()){
    ui_todo("Add the following line to badge area of the {usethis::ui_value('README.Rmd')} file")
    ui_code_block("![Coverage](`r mskRutils::use_covr_badge()`)")
    return(invisible())
  }

  # calculating coverage
  cov_pct <- covr::package_coverage() %>%
    covr::percent_coverage() %>%
    round()

  # picking badge color
  cov_color <- case_when(
    cov_pct >= 90 ~ "brightgreen",
    cov_pct >= 75 ~ "yellowgreen",
    cov_pct >= 50 ~ "yellow",
    cov_pct >= 25 ~ "orange",
    TRUE ~ "red"
  )

  # saving badge URL
  cov_url <- paste0("https://img.shields.io/badge/Code%20Coverage-",
                    cov_pct, "%25-",cov_color)

  # return badge URL
  cov_url
}

