#' MSKCC GitHub Personal Access Token (PAT)
#'
#' \lifecycle{experimental}
#' Functions for setting up an MSK GitHub PAT (`create_github_msk_token()`),
#' and accessing the saved PAT (`github_msk_token()`).
#'
#' @section Setup:
#'
#' The [Git Configuration Vignette](https://github.mskcc.org/pages/datadojo/mskRutils/articles/git_config.html)
#' will walk you through the PAT setup process
#'
#' @export
#' @rdname github_msk_token
github_msk_token <- function() {

  # try to get MSK PAT stored with gitcreds
  token <-
    tryCatch(
      gh::gh_token(api_url = "https://github.mskcc.org"),
      error = function(e) {
        ui_oops("There was an error retrieving your MSKCC PAT.")
        ui_todo("Re-setup your PAT. Details at")
        usethis::ui_code_block("https://github.mskcc.org/pages/datadojo/mskRutils/articles/git_config.html")
        message(as.character(e))
        return("")
      }
    )

  # if above didn't work, try looking in the env variable (old version, now defunct)
  if (token == "") token <- Sys.getenv("GITHUB_MSK_PAT")

  if (token == "") {
    paste("A Personal Access Token (PAT) has not been",
          "set up for your MSK GitHub account.") %>%
      ui_oops()

    paste("You must setup your MSK GitHub credentials using the {ui_field('gitcreds')} package.",
          "Visit the {ui_value('Git Configuration')} vignettte",
          "for step-by-step instructions.") %>%
      usethis::ui_todo()

    usethis::ui_code_block("https://github.mskcc.org/pages/datadojo/mskRutils/articles/git_config.html")
  }

  class(token) <- "gh_pat"
  token
}

#' @export
#' @inheritParams usethis::create_github_token
#' @rdname github_msk_token
create_github_msk_token <- function(scopes = c("repo", "user", "gist", "workflow")) {

  usethis::create_github_token(
    scopes = scopes,
    description = "R:GITHUB_MSK_PAT",
    host = "https://github.mskcc.org"
  )
}

#' Install a package directly from MSKCC's GitHub Enterprise.
#'
#' \lifecycle{experimental}
#' This is a wrapper for [remotes::install_github()] to make it easier to access
#' MSKCC's instance of GitHub Enterprise. To use this function you must first
#' set up a Personal Access Token (PAT) for your MSK GitHub account. Set up
#' your PAT by running [browse_github_msk_token()]
#'
#' @inheritParams remotes::install_github
#' @seealso [remotes::install_github()]
#' @export
#' @author Daniel D. Sjoberg

install_github_msk <- function(repo,
                               ref = "master",
                               subdir = NULL,
                               ...) {
  remotes::install_github(
    repo,
    ref = ref,
    subdir = subdir,
    auth_token = github_msk_token(),
    host = "github.mskcc.org/api/v3",
    ...
  )
}

#' Connect a local repo with MSK GitHub
#'
#' Function in a wrapper for `usethis::use_github()` with the GitHub instance
#' set to MSK Enterprise GitHub.
#'
#' @inheritParams usethis::use_github
#'
#' @export
#' @seealso Review [`usethis::use_github()`] for details.

use_github_msk <- function(organisation = NULL,
                           private = FALSE,
                           protocol = usethis::git_protocol()) {
  usethis::use_github(
    organisation = organisation,
    private = private,
    protocol = protocol,
    host = "https://github.mskcc.org"
  )
}

# for R < v3.5.0
isFALSE = function(x) {
  is.logical(x) && length(x) == 1L && !is.na(x) && !x
}
