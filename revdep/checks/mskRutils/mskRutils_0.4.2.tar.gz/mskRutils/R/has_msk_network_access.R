#' Check for MSK Network Access
#'
#' @return logical
#' @author Daniel D. Sjoberg
#' @export
#'
#' @examples
#' has_msk_network_access()

has_msk_network_access <- function() {
  # if the MSK GitHub site is accessible, return TRUE
  curl::nslookup("github.mskcc.org", error = FALSE) %>%
    rlang::is_string()
}
