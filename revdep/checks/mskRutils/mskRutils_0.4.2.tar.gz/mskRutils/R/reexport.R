# starter ----------------------------------------------------------------------
#' @export
#' @importFrom starter create_symlink
starter::create_symlink
