#' Write a template file
#'
#' \lifecycle{experimental}
#' Rather than using `create_msk_project()` to start a new project folder, you
#' may use `use_msk_file()` to write a single file from any project template.
#' The functions `use_msk_gitignore()` and `use_msk_readme()` are shortcuts for
#' `use_msk_file("gitignore")` and `use_msk_file("readme")`.
#'
#' @param name Name of file to write.  Not sure of the files available to you?
#' Run the function without specifying a name, and all files available within the
#' template will print.
#' @param filename Optional argument to specify the name of the file to be written.
#' Paths/filename is relative to project base (e.g. `here::here()`)
#' @param open If `TRUE`, opens the new file.
#' @inheritParams create_msk_project
#' @name use_msk_file
#' @rdname use_msk_file
#' @seealso [create_msk_project]
#' @seealso [Vignette for create_msk_project()](https://github.mskcc.org/pages/datadojo/mskRutils/articles/create_msk_project.html)
#' @export
#' @examples
#' \donttest{
#' \dontrun{
#' # create MSK gitignore file
#' use_msk_file("gitignore")
#' use_msk_gitignore()
#'
#' # create MSK README.md file
#' use_msk_file("readme")
#' use_msk_readme()
#' }
#' }

use_msk_file <- function(name = NULL, filename = NULL,
                         template = NULL, open = interactive()) {
  starter::use_project_file(
    name = name,
    filename = filename,
    template = get_template(template),
    open = open
  )
}

#' @rdname use_msk_file
#' @export
use_msk_gitignore <- function(filename = NULL, template = NULL) {
  use_msk_file(name = "gitignore", filename = filename, template = template)
}

#' @rdname use_msk_file
#' @export
use_msk_readme <- function(filename = NULL, template = NULL) {
  use_msk_file(name = "readme", filename = filename, template = template)
}

