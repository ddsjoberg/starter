#' Start a new project
#'
#' Creates a directory with the essential files for
#' a new project. The function can be used on existing project directories as well.
#' Existing files will NOT be overwritten. Rather, the user will be prompted
#' whether to replace the existing file with the template file.
#' The directory is populated with custom `README.md`, `.gitignore`, and
#' `<name>.Rproj` files when utilizing the `default` template.
#'
#' @section Personalized Template:
#' Users can create a
#' personalized project template. Check out the
#' \href{https://github.mskcc.org/pages/datadojo/mskRutils/articles/create_msk_project.html}{vignette}
#' for step by step instructions.
#'
#' @section RStudio Template:
#' The default template is available via the RStudio 'New Project' button.
#' Select 'New Directory', then 'MSKCC Project Template'.
#'
#' @param path A path. If it exists, it is used. If it does not exist, it is
#' created.
#' @param path_data A path. The directory where the secure data exist. Default is
#' `NULL`.  When supplied, code to create symbolic link to data folder is returned.
#' @param template Quoted list object defining a project template. Default is
#' `mskRutils::default_project_template`. Aliases that are also available for select
#' project templates.
#' \describe{
#'   \item{`"default"`}{`mskRutils::default_project_template` Generic project template suitable for work at MSK}
#'   \item{`"hot"`}{`hotverse::project_template` Template for the Health Outcomes Team}
#'   \item{`"biostat"`}{`biostatR::project_template` Template for Biostatistics projects}
#'   \item{`"adstools"`}{`ADSTools::project_template` Template for the Applied Data Science team projects}
#' }
#' @param git Logical indicating whether to create Git repository.  Default is `TRUE`
#' package folder. Modify only if you've created your own project template.
#' @param renv Logical indicating whether to add renv to a project.
#' Default is `NA`, which interactively asks user preference.
#' @param overwrite Overwrite any existing files if they exist.  Options are
#' "no", "yes", and "ask".  Default is "ask"
#' @inheritParams usethis::create_project
#' @author Daniel D. Sjoberg
#' @examples
#' # specifying project folder location (folder does not yet exist)
#' project_path <- fs::path(tempdir(), "My Project Folder")
#'
#' # creating folder where secure data would be stored (typically will be a network drive)
#' secure_data_path <- fs::path(tempdir(), "secure_data")
#' dir.create(secure_data_path)
#'
#' # creating new project folder
#' create_msk_project(project_path, path_data = secure_data_path)
#' @seealso [use_msk_file]
#' @seealso [Vignette for create_msk_project()](https://github.mskcc.org/pages/datadojo/mskRutils/articles/create_msk_project.html)
#' @export


create_msk_project <- function(path, path_data = NULL, template = NULL,
                               git = TRUE, renv = NA, overwrite = c("ask", "no", "yes"),
                               open = interactive()) {
  # path_data fix --------------------------------------------------------------
  # An empty path_data in the GUI project setup passes an empty string instead of NULL.
  if (!is.null(path_data) && path_data == "") {
    path_data <- NULL
  }

  starter::create_project(
    path = path,
    path_data = path_data,
    template = get_template(template),
    git = git,
    renv = renv,
    overwrite =
      match.arg(overwrite) %>%
      switch("ask" = NA, "no" = FALSE, "yes" = TRUE),
    open = open
  )
}

#' This function is used for the New Project button in RStudio
#' @keywords internal
#' @export
create_msk_project_gui <- partial(create_msk_project, open = FALSE)


get_template <- function(template) {
  template_option <-
    getOption("mskRutils.create_msk_project.template", default = "default")

  # user specified template
  template %||%
    # when option is a string linked to a pre-specified template
    switch(
      rlang::is_string(template_option),
      switch(
        template_option,
        "hot" = eval(parse(text = "hotverse::project_template")),
        "biostat" = eval(parse(text = "biostatR::project_template")),
        "adstools" = eval(parse(text = "ADSTools::project_template")),
        "default" = mskRutils::default_project_template
      )
    ) %||%
    # template option is a quoted list
    template_option
}
