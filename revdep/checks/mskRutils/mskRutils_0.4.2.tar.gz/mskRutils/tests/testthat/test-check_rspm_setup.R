test_that("No errors with `check_rspm_setup()`", {
  expect_error(
    check_rspm_setup(),
    NA
  )
})
