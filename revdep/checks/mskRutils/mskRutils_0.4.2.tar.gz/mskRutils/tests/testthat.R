library(testthat)
library(mskRutils)

test_check("mskRutils")
