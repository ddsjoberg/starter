library(testthat)
library(bstfun)

test_check("bstfun")
